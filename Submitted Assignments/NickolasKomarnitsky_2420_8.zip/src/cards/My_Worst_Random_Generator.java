package cards;


/**
 * Nickolas Komarnitsky and Porter Anderson
 * u0717854
 * 3/22/2017
 * 2420
 * Assignment 06
 * I pledge that the work done here was my own and that I have learned how to write this program, such that I could throw it out and restart and finish it in a timely manner. I am not turning in any work that I cannot understand, describe, or recreate. (Name)
 * Nickolas Komarnitsky and Porter Anderson
 */
public class My_Worst_Random_Generator implements Random_Generator {
    @Override
    public int next_int(int max) {
        return 0;
    }

    @Override
    public void set_seed(long seed) {

    }

    @Override
    public void set_constants(long const1, long const2) {

    }
}
