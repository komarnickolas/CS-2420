Nickolas Komarnitsky
u0717854
2/15/2017
2420
Assignment 05
Jessica Murdock

This program takes in multiple kinds of sorting algorithm and displays a GUI containing timing data

When I first got the assignment and ran it, the table being displayed in the command line was a little small for me so I made a quick JavaFX program to display the data, the unsorted and sorted arrays, and the name of the sort. My "Main" class is called SortEvaluations and that is the GUI as well. With my partner we wrote functionality to take the timing data and put it into a text file that excel could process and turn into a graph.

I pledge that the work done here was my own and that I have learned how to write this program, such that I could throw it out and restart and finish it in a timely manner. I am not turning in any work that I cannot understand, describe, or recreate.
Nickolas Komarnitsky
