Nickolas Komarnitsky
u0717854
4/22/2017
2420
Assignment 12

I pledge that the work done here was my own and that I have learned how to write this program, such that I could throw it out and restart and finish it in a timely manner. I am not turning in any work that I cannot understand, describe, or recreate. (Name)
Nickolas Komarnitsky
