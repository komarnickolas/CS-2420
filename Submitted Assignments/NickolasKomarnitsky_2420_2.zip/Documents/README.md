Nickolas Komarnitsky
u0717854
01/19/2017
CS-2420
Assignment02