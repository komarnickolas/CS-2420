package cs2420.Tests;

import javafx.concurrent.Task;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Nickolas Komarnitsky
 * u0717854
 * 4/14/2017
 * 2420
 * Assignment 06
 * I pledge that the work done here was my own and that I have learned how to write this program, such that I could throw it out and restart and finish it in a timely manner. I am not turning in any work that I cannot understand, describe, or recreate. (Name)
 * Nickolas Komarnitsky
 */
public class Test extends Task<Integer>{

    private Indicator indicator;
    private PrintWriter pw;
    private FileWriter fw;
    private Long start, end, total;
    private int num_of_runs;
    public Test(){
        indicator = new Indicator();
        indicator.bind(this);
        num_of_runs=1;
        total = new Long(0);
    }

    @Override
    protected Integer call() throws Exception {
        return null;
    }

    public void setWriter(String filename) throws IOException {
        fw = new FileWriter(filename);
        pw = new PrintWriter(fw);
    }

    public void start(){
        start = System.nanoTime();
    }

    public void end(){
        end = System.nanoTime();
        total += (end-start);
    }

    public void println(String line){
        pw.println(line);
    }

    public void close(){
        pw.close();
    }

    public Indicator getIndicator() {
        return indicator;
    }

    public PrintWriter getPw() {
        return pw;
    }

    public void setPw(PrintWriter pw) {
        this.pw = pw;
    }

    public FileWriter getFw() {
        return fw;
    }

    public void setFw(FileWriter fw) {
        this.fw = fw;
    }

    public Long getTotal() {
        total /= num_of_runs;
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public int getNum_of_runs() {
        return num_of_runs;
    }

    public void setNum_of_runs(int num_of_runs) {
        this.num_of_runs = num_of_runs;
    }
}
